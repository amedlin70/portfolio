package chess;

public interface Constants {
	public static final int MAX_BOARD_SIZE = 8;
}
