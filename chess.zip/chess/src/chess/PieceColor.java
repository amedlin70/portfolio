package chess;

public enum PieceColor{BLACK, WHITE}
